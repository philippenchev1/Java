package softuni.exam.models.entity.enums;

public enum Genre {
        CLASSIC_LITERATURE,
        SCIENCE_FICTION,
        FANTASY
    }