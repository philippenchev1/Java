package softuni.exam.models.dto;

public class BookDto {
    private String title;

    public String getTitle() {
        return title;
    }

    public BookDto setTitle(String title) {
        this.title = title;
        return this;
    }
}
