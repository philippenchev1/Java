package softuni.exam.service.impl;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.ValidationUtils;
import softuni.exam.models.dtos.jsons.ConstellationSeedDto;
import softuni.exam.models.dtos.jsons.StarSeedDto;
import softuni.exam.models.entity.Constellation;
import softuni.exam.models.entity.Star;
import softuni.exam.models.enums.StarType;
import softuni.exam.repository.ConstellationRepository;
import softuni.exam.repository.StarRepository;
import softuni.exam.service.StarService;
import softuni.exam.util.ValidationUtil;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class StarServiceImpl implements StarService {
    private static final String STARS_FILE_PATH = "src/main/resources/files/json/stars.json";

    private final StarRepository starRepository;
    private final ConstellationRepository constellationRepository;
    private final ValidationUtil validationUtil;
    private final ModelMapper modelMapper;
    private final Gson gson;

    @Autowired
    public StarServiceImpl(StarRepository starRepository, ConstellationRepository constellationRepository, ValidationUtil validationUtil, ModelMapper modelMapper, Gson gson) {
        this.starRepository = starRepository;
        this.constellationRepository = constellationRepository;
        this.validationUtil = validationUtil;
        this.modelMapper = modelMapper;
        this.gson = gson;
    }

    @Override
    public boolean areImported() {
        return this.starRepository.count() > 0;
    }

    @Override
    public String readStarsFileContent() throws IOException {
        return Files.readString(Path.of(STARS_FILE_PATH));
    }

    @Override
    public String importStars() throws IOException {
        StringBuilder sb = new StringBuilder();

        List<StarSeedDto> starSeedDtos =
                Arrays.stream(this.gson.fromJson(readStarsFileContent(), StarSeedDto[].class))
                        .collect(Collectors.toList());


        for (StarSeedDto starSeedDto : starSeedDtos) {
            sb.append(System.lineSeparator());

            if (this.starRepository.findByName(starSeedDto.getName()).isPresent() ||
                    !this.validationUtil.isValid(starSeedDto)) {
                sb.append("Invalid star");
                continue;
            }
            Star star = this.modelMapper.map(starSeedDto, Star.class);
            star.setStarType(StarType.valueOf(starSeedDto.getStarType()));
            star.setConstellation(this.constellationRepository.getById(starSeedDto.getConstellation()));

            this.starRepository.save(star);

            sb.append(String.format("Successfully imported star %s - %.2f light years",starSeedDto.getName(),
                    starSeedDto.getLightYears()));

        }



        return sb.toString().trim();
    }

    @Override
    public String exportStars() {
        return null;
    }
}
