package softuni.exam.models.dto;

import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class AstronomerSeedDto {

    @XmlElement(name = "first_name")
    private String firstName;
    @XmlElement(name = "last_name")
    private String lastName;
    @XmlElement(name = "salary")
    private Double salary;
    @XmlElement(name = "average_observation_hours")
    private Double averageObservationHours;
    @XmlElement(name = "birthday")
    private String birthday;
    @XmlElement(name = "observing_star_id")
    private Long observingStar;



    @DecimalMin(value = "15000")
    @NotNull
    public Double getSalary() {
        return salary;
    }

    public AstronomerSeedDto setSalary(Double salary) {
        this.salary = salary;
        return this;
    }

    @NotNull
    @DecimalMin(value = "500")
    public Double getAverageObservationHours() {
        return averageObservationHours;
    }

    public AstronomerSeedDto setAverageObservationHours(Double averageObservationHours) {
        this.averageObservationHours = averageObservationHours;
        return this;
    }


    @NotNull
    @Size(min = 2,max = 30)
    public String getFirstName() {
        return firstName;
    }

    public AstronomerSeedDto setFirstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    @NotNull
    @Size(min = 2,max = 30)
    public String getLastName() {
        return lastName;
    }

    public AstronomerSeedDto setLastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    public String getBirthday() {
        return birthday;
    }

    public AstronomerSeedDto setBirthday(String birthday) {
        this.birthday = birthday;
        return this;
    }

    public Long getObservingStar() {
        return observingStar;
    }

    public AstronomerSeedDto setObservingStar(Long observingStar) {
        this.observingStar = observingStar;
        return this;
    }
}
