package softuni.exam.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import softuni.exam.models.entity.Astronomer;
import softuni.exam.models.entity.enums.StarType;

import java.util.Optional;
import java.util.Set;

@Repository
public interface AstronomerRepository extends JpaRepository<Astronomer, Long> {

    Set<Astronomer> findAllByAverageObservationHours(Double avgObservationHours);

    Optional<Astronomer> findByFirstNameAndLastName(String firstName, String lastName);
}
